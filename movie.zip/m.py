from dataclasses import replace
from pyrogram.errors import FloodWait
import traceback
import io
import os
import logging
from pyrogram import *
import time
from datetime import datetime
from pyrogram.types import *
from os import environ, execle, path, remove
import sys
import json

import asyncio

#from youtubesearchpython import SearchVideos

bot_token = "5566519561:AAEqkZW9VPO6XVhfsvgQROTPlBLKzsBdbl0"

bot2 = Client(
    'movie_bot',
    bot_token=bot_token,
    api_id=2736498,
    api_hash="d47c7c0c33c194749aed03acea1d8a34"
)

bot = Client(
    'ashit_wbot',
    api_id=2736498,
    api_hash="d47c7c0c33c194749aed03acea1d8a34"
)

channels = [-1001771537224, -1001651510920]
admins = [1602293216, 809293242, 19371046, -1001889767694, 1001889767694, 1889767694]
log_chat = -1001791797833
store_channels = [-1001521466791, -1001758042349, -1001506343259]

bot_id = 5566519561




@bot.on_message(filters.chat(-1001506343259))
async def forwaedit(c, m):
 #   print(m.caption)
    if "@" in str(m.caption):
       cap = str(m.caption).replace("@", "")
       await m.edit_caption(cap)
    if "uploaded by" in str(m.caption).lower():
       cap = str(m.caption).split("Uploaded", 1)[0]
#       print("esit cap")
       await m.edit_caption(f"{cap}\nFollow @TVmoviesHD & @HD_10TV for more")
    





@bot.on_message(filters.chat(-1001621743345))
async def forwhdhdjdjdnenrndnra(c, m):
    print("okey")
    if m.video or m.document:
        print("okey 2")
#        print(m)
        if "mkv" in str(m.caption):        
            cap = str(m.caption.split("mkv", 1)[0]) + "mkv"
        if "@" in str(m.caption):
            cap = m.caption.replace("@", "")
        ncap = ""
        if m.video:
          ncap = m.video.file_name
        if m.document:
            ncap = m.document.file_name
        ncap = ncap.replace("_", " ")
        ncap += "\nFollow @TVmoviesHD & @HD_10TV for more"
        
        await m.copy(-1001521466791, caption=ncap)
@bot.on_message(filters.chat(-1001416810160))
async def forwa(c, m):
    if m.video or m.document:
      if (m.document and (str(m.document.file_name).lower().endswith("mkv") or str(m.document.file_name).lower().endswith("mp4"))) or m.video:
        if "@" in str(m.caption):
            cap = m.caption.replace("@", "")
        else:
             cap = m.caption
        if "check" in m.caption.lower():
           cap = m.caption.replace("check", "")
        await m.copy(-1001506343259)

@bot2.on_message(filters.chat(-1001416810160))
async def forwa(c, m):
    if m.video or m.document:
      if (m.document and (str(m.document.file_name).lower().endswith("mkv") or str(m.document.file_name).lower().endswith("mp4"))) or m.video:
        if "@" in str(m.caption):
            cap = m.caption.replace("@", "")
        else:
             cap = m.caption
        if "check" in m.caption.lower():
           cap = m.caption.replace("check", "")
        await m.copy(-1001506343259)

@bot2.on_message(filters.chat(-1001791797833))
async def rep(c, m):
     if m.reply_to_message:
           mes = m.reply_to_message.text
           try:
               chat_id = int(mes.split()[0])
               await m.copy(chat_id)
               await m.reply_text("success")
           except Exception as e:            
               await m.reply_text("Failed to reply")


#@bot2.on_message(filters.chat(-1001486308601))
async def rep(c, m):
     if m.reply_to_message and m.reply_to_message.from_user.id == 5566519561:
           mes = m.reply_to_message.text
           try:
               chat_id = int(mes.split()[0])
               await m.copy(chat_id)
               await m.reply_text("success")
           except Exception as e:            
               await m.reply_text("Failed to reply")

import base64

async def _encode(message) -> str:
   message_bytes = message.encode('ascii')
   base64_bytes = base64.b64encode(message_bytes)
   base64_message = base64_bytes.decode('ascii')

   return base64_message

async def _decode(base64_message) -> str:
   base64_bytes = base64_message.encode('ascii')
   message_bytes = base64.b64decode(base64_bytes)
   message = message_bytes.decode('ascii')

   return message



def s_decode(base64_message) -> str:
   base64_bytes = base64_message.encode('ascii')
   message_bytes = base64.b64decode(base64_bytes)
   message = message_bytes.decode('ascii')

   return message
   
@bot2.on_message(filters.command("broadcast") & filters.user(admins))
async def bro(client, message):
    status_message = await message.reply_text("Processing ...")
    if not message.reply_to_message:
       return
    with open("users.txt", "r") as red:
         gandus = json.load(red)
    success = 0
    failed = 0
    for gandu in gandus["users"]:
        try:
           await message.reply_to_message.copy(gandu)
           success += 1
        except:
            failed += 1
    await status_message.edit(f"Total = {len(gandus['users'])}\n success = {success}, failed = {failed}")
    




@bot2.on_message(filters.command("e") & filters.user(admins))
async def eval(client, message):
    status_message = await message.reply_text("Processing ...")
    cmd = message.text.split(" ", maxsplit=1)[1]
    reply_to_ = message
    if message.reply_to_message:
        reply_to_ = message.reply_to_message

    old_stderr = sys.stderr
    old_stdout = sys.stdout
    redirected_output = sys.stdout = io.StringIO()
    redirected_error = sys.stderr = io.StringIO()
    stdout, stderr, exc = None, None, None

    try:
        await aexec(cmd, client, message)
    except Exception:
        exc = traceback.format_exc()

    stdout = redirected_output.getvalue()
    stderr = redirected_error.getvalue()
    sys.stdout = old_stdout
    sys.stderr = old_stderr

    evaluation = ""
    if exc:
        evaluation = exc
    elif stderr:
        evaluation = stderr
    elif stdout:
        evaluation = stdout
    else:
        evaluation = "Success"

    final_output = "<b>EVAL</b>: "
    final_output += f"<code>{cmd}</code>\n\n"
    final_output += "<b>OUTPUT</b>:\n"
    final_output += f"<code>{evaluation.strip()}</code> \n"

    if len(final_output) > 4000:
        with io.BytesIO(str.encode(final_output)) as out_file:
            out_file.name = "eval.text"
            await reply_to_.reply_document(
                document=out_file,
                caption=cmd[: 4000 // 4 - 1],
                disable_notification=True,
                quote=True,
            )
    else:
        await reply_to_.reply_text(final_output, quote=True)
    await status_message.delete()


async def aexec(code, client, message):
    exec(
        "async def __aexec(client, message): "
        + "".join(f"\n {l_}" for l_ in code.split("\n"))
    )
    return await locals()["__aexec"](client, message)


# @bot2.on_message(filters.command("start"))
async def add_gandus(c, m):
    gandu = m.from_user.id
    with open("users.txt", "r") as red:
        users = json.load(red)
    if not gandu in users["users"]:
        users["users"].append(gandu)
        with open("users.txt", "w+") as red:
            json.dump(users, red, indent=4)
        ww = f"#stared_user\nAdded another gandu `{gandu}` {m.from_user.mention} to users list"
        await bot2.send_message(log_chat, ww)
    await m.reply_text("Just send movie or series name,i will search it for you!")

def add_gandus_2(c, m):
    gandu = m.from_user.id
    with open("users.txt", "r") as red:
        users = json.load(red)
    if not gandu in users["users"]:
        users["users"].append(gandu)
        with open("users.txt", "w+") as red:
            json.dump(users, red, indent=4)
        ww = f"#stared_user\nAdded another gandu `{gandu}` {m.from_user.mention} to users list"
        bot2.send_message(log_chat, ww)
    m.reply_text("Just send movie or series name,i will search it for you!")



@bot2.on_message(filters.command(["mban", "munban"]) & filters.user(admins))
def ban_gandus(c, m):
    gandu = int(m.command[1])
    with open("users.txt", "r") as red:
        users = json.load(red)

    if m.command[0] == "mban":
        if not gandu in users["banned"]:
            users["banned"].append(gandu)
            with open("users.txt", "w+") as red:
                json.dump(users, red, indent=4)
            ww = f"Banned another gandu `{gandu}` "
            m.reply_text(ww)
    else:
        users["banned"].remove(gandu)
        with open("users.txt", "w+") as red:
            json.dump(users, red, indent=4)
        ww = f"Unbanned another gandu `{gandu}` "
        m.reply_text(ww)

    bot2.send_message(log_chat, ww)


@bot2.on_message(filters.command(["restart"]) & filters.user(admins))
async def restart(client, message):
    await message.reply_text(f"`ʀᴇsᴛᴀʀᴛed`")
    await bot2.send_message(log_chat, "Restarted")
    args = [sys.executable, "m.py"]
    execle(sys.executable, *args, environ)
    exit()
    return


@bot2.on_message(filters.command("movie") & filters.user(admins))
async def search_movies(c, m):
    if m.from_user and m.text and " " in m.text:
        proc = await m.reply_text("Processing ..")
        await proc.edit(m.text.split(" ", 1)[1], reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(
                    text=f"search in series (English)", callback_data=f"series_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (English)", callback_data=f"movies_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (Hindi)", callback_data=f"movies_hin"), ],

            ])
        )


@bot2.on_message(filters.chat(-1001791797833))
async def rep(c, m):
     if m.reply_to_message:
           mes = m.reply_to_message.text
           try:
               chat_id = int(mes.split()[1])
               await m.copy(chat_id)
               await m.reply_text("success")
           except:
               await m.reply_text("Failed to reply")
               
               
@bot2.on_message(filters.private & filters.text)
def movie(c, m):
    hmm = None
    channel1 = None
    if m.reply_to_message and m.reply_to_message.text and m.reply_to_message.from_user.id == 5566519561:
          stext = m.text
#          await c.send_message(-1001486308601, f"`{m.from_user.id}`\n#REPLY\n{stext}\n{m.from_user.mention}")
          c.send_message(-1001791797833, f"`{m.from_user.id}`\n#REPLY\n{stext}\n{m.from_user.mention}")        
          return 
    if m.text.strip() == "/start":
        add_gandus_2(c, m)
        return
    elif m.text[1:].startswith('start'):
        try:
            hmm111 = str(m.text).split('/start ', 1)[1]
            if not "_" in hmm111:
                hmm = s_decode(hmm111)
            else:
                hmm = hmm111
            if "_" in hmm:
                hmm = (hmm.replace("_", " ")).strip()
            if "-100" in hmm:
                hm1 = hmm.split("-100")
                hmm = hm1[0]
                ch = (hm1[1]).strip()
                if ch == "ens":
                    channel1 = -1001521466791
                elif ch == "enm":
                    channel1 = -1001758042349
                elif ch == "him":
                    channel1 = -1001506343259
            print(hmm)
        except Exception as e:
            print(e)
            hmm = None

    if not hmm:
        hmm = m.text
    print(hmm, channel1)
    id = m.from_user.id
    user = m.from_user.mention
    is_member = None
    with open("users.txt", "r") as red:
        users = json.load(red)
    if id in users["banned"]:
        return
    proc = m.reply_text("Processing ..")
    # await bot2.send_message(log_chat, f"`{id}` {user} searched {hmm}")

    for gandu in channels:
        try:
            c.get_chat_member(chat_id=gandu, user_id=id)
            is_member = True

        except:
            is_member = False
            proc.edit(f"""Hey {user} , in order to use me in private
you have to join our movie channels,

@TVmoviesHD & @HD_10TV

Thank you !
""",
                            reply_markup=InlineKeyboardMarkup(
                                [
                                    [InlineKeyboardButton(
                                        text=f"Refresh and verify !", callback_data=f"verify_{id}"), ]
                                ])
                            )
            ww = f"`{id}` trying without joining group \n {m.from_user.first_name} {m.from_user.last_name}"
            bot2.send_message(log_chat, ww)
            break

    if is_member and str(channel1).startswith("-100"):

        k = []
        chat_id = m.from_user.id

        for message in bot.search_messages(channel1, query=hmm):
            k.append(message.id)

        if not k:
            proc.edit("No files found !\nMake sure to use correct spelling \nor search with a smaller name !")
            bot2.send_message(log_chat, f"`{m.from_user.id}` {m.from_user.mention} searched {hmm}")

            return
        k.sort()
       
        proc.edit(f"{len(k)} results for **{hmm}**")
        spam1(c, chat_id, channel1, k)
        bot2.send_message(log_chat, f"`{m.from_user.id}` {m.from_user.mention} searched {hmm}")

    elif is_member:
        proc.edit(hmm, reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(
                    text=f"search in series (English)", callback_data=f"series_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (English)", callback_data=f"movies_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (Hindi)", callback_data=f"movies_hin"), ],


            ])
        )

        bot2.send_message(log_chat, f"`{m.from_user.id}` {m.from_user.mention} searched {m.text}")
        return

data = {}





async def search_res(m, chat_id, movie_name) -> str:
        text = movie_name.replace(" ", "").replace(" ", "").replace("_", "").replace(".", "")
        proc = m.reply_text("Searching ..")
        k = []
        for chnl in store_channels:
          async for message in bot.search_messages(chnl, query=movie_name):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)
        if not k:
            await proc.edit("No files found !\nMake sure to use correct spelling \nor search with a smaller name !")
            return
        k.sort()
        await spam(c, chat_id, -1001521466791, k)

        await proc.edit(f"{len(k)} Results for **{m.message.text}**")






@bot2.on_message(filters.command(["ph", "pm", 'ps']) & filters.user(admins))
async def posting(client, message):
    user = message.from_user.id
    if not message.reply_to_message:
        await message.reply_text("Reply to a image retard sir")
        return
    elif message.reply_to_message.photo:
        try:
            movie_name = (message.text.split(' ', 1)[
                          1]).replace(" ", "_").strip()
        except:
            await message.reply_text("Enter a valid Movie/Series name retard sar")
            return
        if message.text.split(' ', 1)[0] == "/pm":
            this = "Movie"
            code = "-100enm"
        elif message.text.split(' ', 1)[0] == "/ps":
            this = "TV Series"
            code = "-100ens"
        else:
            this = "Hindi Movie/Series"
            code = "-100him"
        msg_id = str(message.id)
        jdsb = msg_id
        movie_name_enc = await _encode(f"{movie_name}_{code}")
        print(movie_name_enc)

        url = f"http://t.me/hd_series_and_movies_bot?start={movie_name_enc}"
        textt = f"""{this} - <b>{movie_name.replace("_", " ")} </b>

<a href="{url}">Click Here to Download</a>

<i>Follow @HD_10TV and @TVmoviesHD for more</i>

Also you can send any movie/Series name to-
@hd_series_and_movies_bot and it will send you the files 😎   """
        data.update({msg_id: {"jdsb": jdsb,
                              "textt": textt,
                              "url": url,
                              "fromchat": message.chat.id,
                              "replyid": message.reply_to_message.id,
                              "movie_name": movie_name
                              }})
        await client.copy_message(
            chat_id=message.chat.id,
            from_chat_id=message.chat.id,
            caption=textt,
            message_id=message.reply_to_message.id,
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Post it ✅",
                            callback_data="post_"+str(msg_id)
                        ),
                        InlineKeyboardButton(
                            "Don't Post ❌",
                            callback_data="abort"
                        ),
                    ]
                ]

            )
        )
    else:
        await message.reply_text("This is not an image")






@bot2.on_callback_query()
async def call_query(c, m):
    if "verify_" in m.data:
        id = int(m.data.split("_")[1])
        for channel in channels:
            try:
                await c.get_chat_member(chat_id=channel, user_id=id)
                is_member = True

            except:
                is_member = False
                if channel == -1001771537224:
                    mgroup = "@TVmoviesHD"
                else:
                    mgroup = "@HD_10TV"
                await m.answer(f"""Nope, still missing!
join {mgroup}""", show_alert=True)
                break

        if is_member:
            await m.message.edit("Verified !")
            return
    elif m.data == "series_eng":
        if not "\n" in m.message.text:
            stext = m.message.text
        else:
           stext = m.message.text.split("\n", 2)[2]
        text = stext.replace(" ", "").replace(" ", "").replace("_", "").replace(".", "")
        print(stext)
        proc = await m.message.edit("Searching ...")

        k = []
        chat_id = m.from_user.id

        async for message in bot.search_messages(-1001521466791, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)
        if not k:
            await proc.edit(f"No files found ! Make sure to use correct spelling or search with a smaller name !\nSearch again?\n__**{stext}**__", reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(
                    text=f"search in series (English)", callback_data=f"series_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (English)", callback_data=f"movies_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (Hindi)", callback_data=f"movies_hin"), ],
               [InlineKeyboardButton(
                    text=f"Cancel ", callback_data=f"abort"), ],
               [InlineKeyboardButton(
                    text=f"REQUEST TO ADMINS", callback_data=f"request"), ],
            ])
        )
            return
        k.sort()
        await proc.edit(f"{len(k)} Results for **{stext}**")
        await spam(c, chat_id, -1001521466791, k)


    elif m.data == "movies_eng":
        if not "\n" in m.message.text:
            stext = m.message.text
        else:
           stext = m.message.text.split("\n", 2)[2]
        text = stext.replace(" ", "").replace(" ", "").replace("_", "").replace(".", "")
        print(stext)
        proc = await m.message.edit("Searching ...")
        k = []
        chat_id = m.from_user.id

        async for message in bot.search_messages(-1001758042349, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)

        if not k:
            await proc.edit(f"No files found ! Make sure to use correct spelling or search with a smaller name !\nSearch again?\n__**{stext}**__", reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(
                    text=f"search in series (English)", callback_data=f"series_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (English)", callback_data=f"movies_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (Hindi)", callback_data=f"movies_hin"), ],
               [InlineKeyboardButton(
                    text=f"Cancel ", callback_data=f"abort"), ],
               [InlineKeyboardButton(
                    text=f"REQUEST TO ADMINS", callback_data=f"request"), ],

            ])
        )
            return
        k.sort()
        await proc.edit(f"{len(k)} Results for **{stext}**")
        await spam(c, chat_id, -1001758042349, k)



    elif m.data == "movies_hin":
        if not "\n" in m.message.text:
            stext = m.message.text
        else:
           stext = m.message.text.split("\n", 2)[2]
        text = stext.replace(" ", "").replace(" ", "").replace("_", "").replace(".", "")
        print(stext)
        proc = await m.message.edit("Searching ...")
        k = []
        chat_id = m.from_user.id

        async for message in bot.search_messages(-1001506343259, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)

        if not k:
            await proc.edit(f"No files found ! Make sure to use correct spelling or search with a smaller name !\nSearch again?\n__**{stext}**__", reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(
                    text=f"search in series (English)", callback_data=f"series_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (English)", callback_data=f"movies_eng"), ],
                [InlineKeyboardButton(
                    text=f"search in movies (Hindi)", callback_data=f"movies_hin"), ],
               [InlineKeyboardButton(
                    text=f"Cancel ", callback_data=f"abort"), ],
               [InlineKeyboardButton(
                    text=f"REQUEST TO ADMINS", callback_data=f"request"), ],
            ])
        )
            return

        k.sort()
        await proc.edit(f"{len(k)} Results for **{stext}**")
        await spam(c, chat_id, -1001506343259, k)


    elif m.data == "abort":
        await m.message.edit("Operation aborted")
        return
    elif m.data == "request":
        stext=""
        if not "\n" in m.message.text:
            stext = m.message.text
        else:
           stext = m.message.text.split("\n", 2)[2]
        await m.message.edit("Request sent to admins.\nYou will be notified soon if it's a legit movie/series name!")
       # await c.send_message(-1001486308601, f"`{m.from_user.id}`\n#REQUEST_MOVIE\n{stext}\n{m.from_user.mention}")
        await c.send_message(-1001791797833, f"`{m.from_user.id}`\n#REQUEST_MOVIE\n{stext}\n{m.from_user.mention}")
        
        return
    elif m.data.startswith('post_'):
        msg = m.message
        await msg.edit("Posting...")
        jdsb = m.data.split('_', 1)[1]
        values = data.get(jdsb)
        movie_name = values["movie_name"]
        await c.copy_message(
            chat_id="@HD_10TV",
            from_chat_id=values["fromchat"],
            caption=values["textt"],
            message_id=values["replyid"],
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Download",
                            url=values["url"]
                        ),
                    ]
                ]

            )
        )
        await m.message.edit(f"Posted {movie_name} Successfully! ")
        return


async def spam(boot, chat_id, new_chat, a):
        for i in a:
            await boot.copy_message(chat_id, new_chat, i)
            await asyncio.sleep(0.5)
def spam1(boot, chat_id, new_chat, a):
        for i in a:
            boot.copy_message(chat_id, new_chat, i)
            time.sleep(0.5)

        boot.forward_messages(new_chat,chat_id, a)



@bot2.on_inline_query(filters.user(admins))
async def ianswer(client, inline_query):
    input = inline_query.query.strip()
    search = SearchVideos(input, offset=1, mode="dict", max_results=50)
    rt = search.result()
    results = []
    xt = rt["search_result"]
    for i in xt:
        v = i["views"] / 1000
        results.append(
            InlineQueryResultArticle(
                title=i["title"],
                description=i["title"],
                thumb_url=i["thumbnails"][0],
                input_message_content=InputTextMessageContent(
                    f""" {i["link"]}
                       \n**Views:** `{i["views"]}` \n**Duration:-**  `{i['duration']}` minute"""

                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "Link",
                        url=i["link"]
                    )
                ]]),

            )
        )

    await inline_query.answer(results, cache_time=5)



@bot2.on_message(filters.command(['link']) & filters.chat([-1001716284663, -1001486308601, -1001889767694]))
async def ilink(c, m): 
     if m.from_user:
         if not m.from_user.id in admins:
             return 
     elif m.sender_chat:
         if not m.sender_chat.id in admins:
             return 
   
         
     if " " in m.text:
         movie = m.text.split(" ",1)[1]
     else:
        await m.reply_text("Movie name not found")
        return
        movie = "Unknown movie"
     links = ""
     stext = movie.strip()
     text = stext.replace(" ", "").replace(" ", "").replace("_", "").replace(".", "")
     if m:
        oke = await m.reply_text("searching..")       
        k = []
      #  chat_id = m.from_user.id
     # for English series
        async for message in bot.search_messages(-1001521466791, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)
        if len(k) > 1:
            code = "-100ens"
            movie_name_enc = await _encode(f"{movie}_{code}")
            url = f"http://t.me/hd_series_and_movies_bot?start={movie_name_enc}"
            links += f"\n[{movie} in English series - {len(k)} results]({url})"
     # for hindi series
        k = []
        async for message in bot.search_messages(-1001758042349, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)
        if len(k) > 1:
            code = "-100enm"
            movie_name_enc = await _encode(f"{movie}_{code}")
            url = f"http://t.me/hd_series_and_movies_bot?start={movie_name_enc}"
            links += f"\n[{movie} in English movies - {len(k)} results]({url})"
     # for English movie
        k = []
        async for message in bot.search_messages(-1001506343259, query=stext):
            if message.video or message.document:
               mtext = (str(message.video.file_name) + str(message.caption) if message.video else str(message.document.file_name) + str(message.caption)).replace(" ", "").replace(".", "").replace("_", "")
               if text.lower() in mtext.lower():
                  k.append(message.id)
        if len(k) > 1:
            code = "-100him"
            movie_name_enc = await _encode(f"{movie}_{code}")
            url = f"http://t.me/hd_series_and_movies_bot?start={movie_name_enc}"
            links += f"\n[{movie} in Hindi movies - {len(k)} results]({url})"

     if links:       
         try:
             await m.reply_to_message.reply_text(links)
             await m.delete()
         except:
             await m.reply_text(links)
     else:
        try:
             await m.reply_to_message.reply_text(f"No results found for {movie}")
             await m.delete()
        except:
             await m.reply_text(f"No results found for {movie}")
     
     await oke.delete()
        
bot2.start()
bot.start()
print("Bot started !")
idle()
bot2.stop()
bot.stop()

